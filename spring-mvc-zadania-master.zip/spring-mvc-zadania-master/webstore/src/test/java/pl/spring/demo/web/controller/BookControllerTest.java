package pl.spring.demo.web.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import pl.spring.demo.constants.ViewNames;
import pl.spring.demo.controller.BookController;
import pl.spring.demo.enumerations.BookStatus;
import pl.spring.demo.service.BookService;
import pl.spring.demo.to.BookTo;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "controller-test-configuration.xml")
@WebAppConfiguration
public class BookControllerTest {

	@Autowired
	private BookService bookService;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		Mockito.reset(bookService);

		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");

		BookController bookController = new BookController();
		mockMvc = MockMvcBuilders.standaloneSetup(bookController).setViewResolvers(viewResolver).build();
		// Due to fact, that We are trying to construct real Bean - Book
		// Controller, we have to use reflection to mock existing field book
		// service
		ReflectionTestUtils.setField(bookController, "bookService", bookService);
	}

	@Test
	public void testAddBookPagePost() throws Exception {
		// given
		BookTo testBook = new BookTo(1L, "Test title", "Test Author", BookStatus.FREE);
		Mockito.when(bookService.saveBook(Mockito.any())).thenReturn(testBook);

		// attribute
		ResultActions resultActions = mockMvc.perform(post("/books/addBook").param("authors", "Test Author")
				.param("title", "Test title").param("status", "FREE")).andDo(print());

		// then
		resultActions.andExpect(view().name(ViewNames.WELCOME))
		.andExpect(status().isOk());
	}

	@Test
	public void testAddBookPageGet() throws Exception {
		// given
		BookTo testBook = new BookTo(1L, "Test title", "Test Author", BookStatus.FREE);
		Mockito.when(bookService.saveBook(Mockito.any())).thenReturn(testBook);

		// attribute
		ResultActions resultActions = mockMvc.perform(get("/books/addBook")).andDo(print());

		// then
		resultActions.andExpect(view().name(ViewNames.ADD_BOOK))
		.andExpect(status().isOk());
	}

	@Test
	public void testSearchBookPageGet() throws Exception {
		// given
		BookTo testBook = new BookTo(1L, "Test title", "Test Author", BookStatus.FREE);
		Mockito.when(bookService.saveBook(Mockito.any())).thenReturn(testBook);

		// attribute
		ResultActions resultActions = mockMvc.perform(get("/books/search")).andDo(print());

		// then
		resultActions.andExpect(view().name("bookSearch"))
		.andExpect(status().isOk());

	}

	@Test
	public void testSearchBookPagePost() throws Exception {
		// given
		BookTo testBook = new BookTo(1L, "Test title", "Test Author", BookStatus.FREE);
		Mockito.when(bookService.saveBook(Mockito.any())).thenReturn(testBook);

		// attribute
		ResultActions resultActions = mockMvc
				.perform(post("/books/search").param("title", "Test title").param("authors", "Test title"))
				.andDo(print());

		// then
		resultActions.andExpect(view().name("books"))
		.andExpect(status().isOk());

	}

	@Test
	public void testDeleteBookPage() throws Exception {
		// given
		BookTo testBook = new BookTo(1L, "Test title", "Test Author", BookStatus.FREE);
		Mockito.when(bookService.saveBook(Mockito.any())).thenReturn(testBook);
		String id = String.valueOf(1L);

		// attribute
		ResultActions resultActions = mockMvc.perform(get("/books/delete").param("id", id)).andDo(print());

		// then
		resultActions.andExpect(view().name("bookDelete"))
		.andExpect(status().isOk());

	}

	@Test
	public void testFindBookByIdPage() throws Exception {
		// given
		BookTo testBook = new BookTo(1L, "Test title", "Test Author", BookStatus.FREE);
		Mockito.when(bookService.saveBook(Mockito.any())).thenReturn(testBook);
		String id = String.valueOf(1L);

		// attribute
		ResultActions resultActions = mockMvc.perform(get("/books/book").param("id", id)).andDo(print());

		// then
		resultActions.andExpect(view().name("book"))
		.andExpect(status().isOk());

	}

	@Test
	public void testAllBookPage() throws Exception {
		// given
		BookTo testBook = new BookTo(1L, "Test title", "Test Author", BookStatus.FREE);
		Mockito.when(bookService.saveBook(Mockito.any())).thenReturn(testBook);

		// attribute
		ResultActions resultActions = mockMvc.perform(get("/books/all")).andDo(print());
		
		// then
		resultActions.andExpect(view().name(ViewNames.BOOKS))
		.andExpect(status().isOk());

	}

	@Test
	public void testDefaultBookPage() throws Exception {
		// given
		BookTo testBook = new BookTo(1L, "Test title", "Test Author", BookStatus.FREE);
		Mockito.when(bookService.saveBook(Mockito.any())).thenReturn(testBook);

		// attribute
		ResultActions resultActions = mockMvc.perform(get("/books")).andDo(print());
		// then
		resultActions.andExpect(view().name(ViewNames.WELCOME))
		.andExpect(status().isOk());

	}

	/**
	 * (Example) Sample method which convert's any object from Java to String
	 */
	/*private static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			final String jsonContent = mapper.writeValueAsString(obj);
			return jsonContent;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}*/
}
