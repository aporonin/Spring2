package pl.spring.demo.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import pl.spring.demo.constants.ModelConstants;
import pl.spring.demo.constants.ViewNames;
import pl.spring.demo.enumerations.BookStatus;
import pl.spring.demo.service.BookService;
import pl.spring.demo.to.BookTo;

/**
 * Book controller
 */
@Controller
@RequestMapping("/books")
public class BookController {

	@Autowired
	private BookService bookService;

	private static final String WELCOME = "Find the best book for you!";

	/**
	 * @param model
	 * @return ViewNames.WELCOME
	 */
	@RequestMapping
	public String list(Model model) {
		model.addAttribute(ModelConstants.INFO, WELCOME);
		return ViewNames.WELCOME;
	}

	/**
	 * @return modelAndView books
	 */
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public ModelAndView allBooks() {
		ModelAndView modelAndView = new ModelAndView("books");
		List<BookTo> allBooks = bookService.findAllBooks();
		modelAndView.addObject("bookList", allBooks);
		return modelAndView;
	}

	/**
	 * @param bookId
	 * @return modelAndView book
	 */
	@RequestMapping(value = "/book", method = RequestMethod.GET)
	public ModelAndView showBook(@RequestParam("id") Long bookId) {
		ModelAndView modelAndView = new ModelAndView("book");
		BookTo book = bookService.findBookById(bookId);
		modelAndView.addObject("book", book);
		return modelAndView;
	}

	/**
	 * @param bookId
	 * @return modelAndView bookDelete
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView deleteBook(@RequestParam("id") Long bookId) {
		ModelAndView modelAndView = new ModelAndView("bookDelete");
		bookService.deleteBook(bookId);
		modelAndView.addObject("bookList");
		return modelAndView;
	}

	/**
	 * @param title
	 * @param author
	 * @return modelAndView books
	 */
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ModelAndView findBookByTitleAndAuthor(@RequestParam("title") String title,
			@RequestParam("authors") String author) {
		ModelAndView modelAndView = new ModelAndView("books");
		Set<BookTo> book = bookService.findBooksByTitleAndAuthor(title, author);
		modelAndView.addObject("bookList", book);
		return modelAndView;
	}

	/**
	 * @return modelAndView bookSearch
	 */
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView findBookByTitleAndAuthor() {
		ModelAndView modelAndView = new ModelAndView("bookSearch");
		BookTo book = new BookTo();
		modelAndView.addObject("searchBook", book);
		return modelAndView;
	}

	/**
	 * @return modelAndView addBook
	 */
	@RequestMapping(value = "/addBook", method = RequestMethod.GET)
	public ModelAndView addBook() {
		ModelAndView modelAndView = new ModelAndView("addBook");
		BookTo addBook = new BookTo();
		modelAndView.addObject("newBook", addBook);
		return modelAndView;
	}

	/**
	 * @param authors
	 * @param title
	 * @param status
	 * @return ViewNames.WELCOME
	 */
	@RequestMapping(value = "/addBook", method = RequestMethod.POST)
	public String addBook(@RequestParam("authors") String authors, @RequestParam("title") String title,
			@RequestParam("status") String status) {
		BookTo addBook = new BookTo(null, title, authors, BookStatus.valueOf(status));
		bookService.saveBook(addBook);
		return ViewNames.WELCOME;
	}

	/**
	 * Binder initialization
	 */
	@InitBinder
	public void initialiseBinder(WebDataBinder binder) {
		binder.setAllowedFields("id", "title", "authors", "status");
	}

}
