package pl.spring.demo.service;

import pl.spring.demo.to.BookTo;

import java.util.List;
import java.util.Set;

public interface BookService {

    /**
     * @return list of all books
     */
    List<BookTo> findAllBooks();
    
    /**
     * @param title
     * @return list of books by title
     */
    List<BookTo> findBooksByTitle(String title);
    
    /**
     * @param author
     * @return list of books by author
     */
    List<BookTo> findBooksByAuthor(String author);
    
    /**
     * @param id
     * @return list of books by id
     */
    BookTo findBookById(Long id);
    
    /**
     * @param title
     * @param author
     * @return list of books by title and author
     */
    Set<BookTo> findBooksByTitleAndAuthor(String title, String author);
 
    /**
     * @param book
     * @return saved book
     */
    BookTo saveBook(BookTo book);
    
    /**
     * @param id
     */
    void deleteBook(Long id);
}
